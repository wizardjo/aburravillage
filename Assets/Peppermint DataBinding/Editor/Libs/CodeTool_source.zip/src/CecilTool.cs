﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

#if UNITY
using UnityEditor;
using UnityEngine;
#endif


namespace Peppermint.DataBinding.Editor
{
    /// <summary>
    /// Cecil code tool.
    /// </summary>
    public static class CodeTool
    {
        public const string AssemblyDirectory = "Library/ScriptAssemblies";

        public static void VerifyPropertyNames()
        {
            var module = new CecilModule();

            // load assembly
            var result = module.Load(AssemblyDirectory);
            if (result == false)
            {
                // load failed
                return;
            }

            try
            {
                DoVerifyPropertyNames(module);
            }
            catch (Exception ex)
            {
#if UNITY
                Debug.LogException(ex);
#else
                Console.WriteLine(ex);
#endif
            }
            finally
            {
#if UNITY
                // clear progress
                EditorUtility.ClearProgressBar();
#endif
            }

            return;
        }

        public static List<KeyValuePair<string, string>> GetBindableProperties()
        {
            var module = new CecilModule();

            // load assembly
            var result = module.Load(AssemblyDirectory);
            if (result == false)
            {
                // load failed
                return null;
            }

            List<KeyValuePair<string, string>> outputList = null;

            try
            {
                outputList = DoGetBindableProperties(module);
            }
            catch (Exception ex)
            {
#if UNITY
                Debug.LogException(ex);
#else
                Console.WriteLine(ex);
#endif
            }
            finally
            {
#if UNITY
                // clear progress
                EditorUtility.ClearProgressBar();
#endif
            }

            return outputList;
        }

        private static void SetProgress(float progress)
        {
#if UNITY
            EditorUtility.DisplayProgressBar("Run CecilTool", "Please waiting...", progress);
#endif
        }

        private static void DoVerifyPropertyNames(CecilModule module)
        {
            SetProgress(0f);

            var classList = module.GetClassList();

            int index = 0;
            float totalStep = classList.Count * 2;

            foreach (var type in classList)
            {
                // update progress
                float progress = index++ / totalStep;
                SetProgress(progress);

                // check all properties
                foreach (var property in type.Properties)
                {
                    // get set method
                    var setMethod = property.SetMethod;
                    if (setMethod == null || !setMethod.HasBody)
                    {
                        continue;
                    }

                    module.CheckSetMethod(setMethod);
                }
            }

            foreach (var type in classList)
            {
                // update progress
                float progress = index++ / totalStep;
                SetProgress(progress);

                var propertyNames = new HashSet<string>(type.Properties.Select(x => x.Name));

                // check all properties
                foreach (var property in type.Properties)
                {
                    // get set method
                    var setMethod = property.SetMethod;
                    if (setMethod == null || !setMethod.HasBody)
                    {
                        continue;
                    }

                    module.CheckMethod(setMethod, propertyNames);
                }

                // check all methods
                foreach (var method in type.Methods)
                {
                    if (!method.HasBody)
                    {
                        continue;
                    }

                    module.CheckMethod(method, propertyNames);
                }
            }
        }

        private static List<KeyValuePair<string, string>> DoGetBindableProperties(CecilModule module)
        {
            SetProgress(0f);

            var classList = module.GetClassList();
            var outputList = new List<KeyValuePair<string, string>>();

            int index = 0;
            float totalStep = classList.Count;

            foreach (var type in classList)
            {
                // update progress
                float progress = index++ / totalStep;
                SetProgress(progress);

                if (type.Properties.Count == 0)
                {
                    continue;
                }

                var propertyNames = new HashSet<string>(type.Properties.Select(x => x.Name));
                var bindablePropertyNames = new HashSet<string>();

                // process all properties
                foreach (var property in type.Properties)
                {
                    // get set method
                    var setMethod = property.SetMethod;
                    if (setMethod == null || !setMethod.HasBody)
                    {
                        continue;
                    }

                    module.ParseSetMethod(setMethod, bindablePropertyNames);
                    module.ParseMethod(setMethod, propertyNames, bindablePropertyNames);
                }

                // process all methods
                foreach (var method in type.Methods)
                {
                    if (!method.HasBody)
                    {
                        continue;
                    }

                    module.ParseMethod(method, propertyNames, bindablePropertyNames);
                }

                // add all bindable property names to output list
                foreach (var item in bindablePropertyNames)
                {
                    var kvp = new KeyValuePair<string, string>(type.FullName, item);
                    outputList.Add(kvp);
                }
            }

            return outputList;
        }
    }
}
