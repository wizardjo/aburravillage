﻿using Mono.Cecil;
using Mono.Cecil.Cil;
using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

#if UNITY
using UnityEngine;
#endif


namespace Peppermint.DataBinding.Editor
{
    /// <summary>
    /// Helper class to manipulate .Net assembly.
    /// </summary>
    public class CecilModule
    {
        private ModuleDefinition frameworkModule;
        private List<TypeDefinition> typeList;

        private HashSet<string> setPropertyMethods;
        private HashSet<string> notifyNotifyPropertyChangedMethods;

        private Func<TypeDefinition, bool> implementsInterface;
        private System.Reflection.PropertyInfo interfacesProperty;
        private System.Reflection.PropertyInfo interfaceTypeProperty;

        private const string InterfaceFullName = "Peppermint.DataBinding.INotifyPropertyChanged";

        public bool Load(string path)
        {
            var valid = LoadModules(path);
            if (!valid)
            {
                return false;
            }

            // get cecil version
            var cecilAssembly = typeof(TypeDefinition).Assembly;
            var cecilVersion = cecilAssembly.GetName().Version.ToString();

            // choose implementation base on the cecil version
            if (cecilVersion == "0.9.6.0")
            {
                implementsInterface = ImplementsINotifyPropertyChangedV1;

                var type = cecilAssembly.GetType("Mono.Cecil.TypeDefinition");
                interfacesProperty = type.GetProperty("Interfaces");
            }
            else
            {
                implementsInterface = ImplementsINotifyPropertyChangedV2;

                var type = cecilAssembly.GetType("Mono.Cecil.TypeDefinition");
                interfacesProperty = type.GetProperty("Interfaces");

                type = cecilAssembly.GetType("Mono.Cecil.InterfaceImplementation");
                interfaceTypeProperty = type.GetProperty("InterfaceType");
            }

            setPropertyMethods = new HashSet<string>();
            notifyNotifyPropertyChangedMethods = new HashSet<string>();


            // get all bindable classes
            var types = typeList.Where(x => IsBindableClass(x));

            // get SetProperty
            foreach (var type in types)
            {
                var methods = GetSetPropertyMethods(type.Methods);

                // add found methods
                foreach (var method in methods)
                {
                    var symbol = GetMethodSymbol(method);
                    setPropertyMethods.Add(symbol);
                }
            }

            // check method count
            if (setPropertyMethods.Count == 0)
            {
#if UNITY
                Debug.LogError("SetProperty method is not found.");
#else
                Console.WriteLine("SetProperty method is not found.");
#endif
                return false;
            }

            // get NotifyPropertyChanged
            foreach (var type in types)
            {
                var methods = GetNotifyPropertyChangedMethods(type.Methods);

                // add found methods
                foreach (var method in methods)
                {
                    var symbol = GetMethodSymbol(method);
                    notifyNotifyPropertyChangedMethods.Add(symbol);
                }
            }

            // check method count
            if (notifyNotifyPropertyChangedMethods.Count == 0)
            {
#if UNITY
                Debug.LogError("NotifyPropertyChanged method is not found.");
#else
                Console.WriteLine("NotifyPropertyChanged method is not found.");
#endif
                return false;
            }

            return true;
        }

        public List<TypeDefinition> GetClassList()
        {
            var list = new List<TypeDefinition>();
            list.AddRange(typeList.Where(x => x.MetadataType == MetadataType.Class));

            foreach (var type in typeList)
            {
                if (!type.HasNestedTypes)
                {
                    continue;
                }

                var nestedTypes = type.NestedTypes.Where(x =>
                {
                    if (x.MetadataType != MetadataType.Class)
                        return false;

                    if (x.HasCustomAttributes)
                    {
                        // ignore compiler generated
                        if (x.CustomAttributes.Any(c => c.AttributeType.Name == "CompilerGeneratedAttribute"))
                        {
                            return false;
                        }
                    }

                    return true;
                });

                list.AddRange(nestedTypes);
            }

            return list;
        }

        public string GetMethodSymbol(MethodReference method)
        {
            var lastParameterTypeName = "null";
            if (method.Parameters.Count > 0)
            {
                lastParameterTypeName = method.Parameters.Last().ParameterType.FullName;
            }

            string result = string.Format("returnTypeName={0}, declaringTypeName={1}, name={2}, parametersCount={3}, lastParameterTypeName={4}",
                method.ReturnType.FullName, method.DeclaringType.FullName, method.Name, method.Parameters.Count, lastParameterTypeName);

            return result;
        }

        public bool IsNotifyPropertyChangedMethod(MethodReference method)
        {
            var symbol = GetMethodSymbol(method);

            // check if signature match
            var result = notifyNotifyPropertyChangedMethods.Contains(symbol);
            return result;
        }

        public bool IsSetPropertyMethod(MethodReference method)
        {
            var symbol = GetMethodSymbol(method);

            // check if signature match
            var result = setPropertyMethods.Contains(symbol);
            return result;
        }

        public void CheckSetMethod(MethodDefinition method)
        {
            // get property name
            const string setPrefix = "set_";
            string propertyName = method.Name.Substring(setPrefix.Length);

            // check method call
            foreach (var instruction in method.Body.Instructions)
            {
                if (instruction.OpCode != OpCodes.Call)
                {
                    continue;
                }

                var operand = instruction.Operand as GenericInstanceMethod;
                if (operand == null)
                {
                    continue;
                }

                // check method SetProperty
                if (!IsSetPropertyMethod(operand))
                {
                    continue;
                }

                // get method argument
                var previousInstruction = instruction.Previous;
                if (previousInstruction.OpCode != OpCodes.Ldstr)
                {
                    continue;
                }

                // check if name match
                var stringArgument = previousInstruction.Operand as string;
                if (propertyName != stringArgument)
                {
                    // log error
                    var propertyFullName = string.Format("{0}.{1}", method.DeclaringType.Name, propertyName);

#if UNITY
                    Debug.LogErrorFormat("Name not match. Expected \"{0}\", but was \"{1}\" in property \"{2}\".",
                        propertyName, stringArgument, propertyFullName);
#else
                    Console.WriteLine("Name not match. Expected \"{0}\", but was \"{1}\" in property \"{2}\".",
                        propertyName, stringArgument, propertyFullName);
#endif

                }
            }
        }

        public void CheckMethod(MethodDefinition method, HashSet<string> propertyNames)
        {
            if (propertyNames.Count == 0)
            {
                return;
            }

            // check method call
            foreach (var instruction in method.Body.Instructions)
            {
                if (instruction.OpCode != OpCodes.Call)
                {
                    continue;
                }

                var operand = instruction.Operand as MethodReference;
                if (operand == null)
                {
                    continue;
                }

                // check method NotifyPropertyChanged
                if (!IsNotifyPropertyChangedMethod(operand))
                {
                    continue;
                }

                // get method argument
                var previousInstruction = instruction.Previous;
                if (previousInstruction.OpCode != OpCodes.Ldstr)
                {
                    continue;
                }

                // check if name match
                var stringArgument = previousInstruction.Operand as string;
                if (!propertyNames.Contains(stringArgument))
                {
#if UNITY
                    Debug.LogErrorFormat("Name not match. Property \"{0}\" not found in class \"{1}\" at method \"{2}\".",
                        stringArgument, method.DeclaringType.FullName, method.FullName);
#else
                    Console.WriteLine("Name not match. Property \"{0}\" not found in class \"{1}\" at method \"{2}\".",
                        stringArgument, method.DeclaringType.FullName, method.FullName);
#endif
                }
            }
        }

        public void ParseSetMethod(MethodDefinition method, HashSet<string> bindablePropertyNames)
        {
            // get property name
            const string setPrefix = "set_";
            string propertyName = method.Name.Substring(setPrefix.Length);

            // check method call
            foreach (var instruction in method.Body.Instructions)
            {
                if (instruction.OpCode != OpCodes.Call)
                {
                    continue;
                }

                var operand = instruction.Operand as GenericInstanceMethod;
                if (operand == null)
                {
                    continue;
                }

                // check method SetProperty
                if (!IsSetPropertyMethod(operand))
                {
                    continue;
                }

                // get method argument
                var previousInstruction = instruction.Previous;
                if (previousInstruction.OpCode != OpCodes.Ldstr)
                {
                    continue;
                }

                // check if name match
                var stringArgument = previousInstruction.Operand as string;
                if (propertyName != stringArgument)
                {
                    continue;
                }

                // check duplicate
                if (bindablePropertyNames.Contains(stringArgument))
                {
                    continue;
                }

                // add it
                bindablePropertyNames.Add(stringArgument);
            }
        }

        public void ParseMethod(MethodDefinition method, HashSet<string> propertyNames, HashSet<string> bindablePropertyNames)
        {
            if (propertyNames.Count == 0)
            {
                return;
            }

            // check method call
            foreach (var instruction in method.Body.Instructions)
            {
                if (instruction.OpCode != OpCodes.Call)
                {
                    continue;
                }

                var operand = instruction.Operand as MethodReference;
                if (operand == null)
                {
                    continue;
                }

                // check method NotifyPropertyChanged
                if (!IsNotifyPropertyChangedMethod(operand))
                {
                    continue;
                }

                // get method argument
                var previousInstruction = instruction.Previous;
                if (previousInstruction.OpCode != OpCodes.Ldstr)
                {
                    continue;
                }

                // check if name match
                var stringArgument = previousInstruction.Operand as string;
                if (!propertyNames.Contains(stringArgument))
                {
                    continue;
                }

                // check duplicate
                if (bindablePropertyNames.Contains(stringArgument))
                {
                    continue;
                }

                // add it
                bindablePropertyNames.Add(stringArgument);
            }
        }

        private IEnumerable<MethodDefinition> GetNotifyPropertyChangedMethods(IEnumerable<MethodDefinition> methods)
        {
            var result = methods.Where(m =>
            {
                if (m.Name != "NotifyPropertyChanged")
                {
                    return false;
                }

                // check return type
                if (m.ReturnType.FullName != "System.Void")
                {
                    return false;
                }

                if (m.Parameters.Count != 1)
                {
                    return false;
                }

                var p0 = m.Parameters[0].ParameterType;
                if (p0.FullName != "System.String")
                {
                    return false;
                }

                return true;
            });

            return result;
        }

        private IEnumerable<MethodDefinition> GetSetPropertyMethods(IEnumerable<MethodDefinition> methods)
        {
            var result = methods.Where(m =>
            {
                if (m.ReturnType.FullName != "System.Boolean")
                {
                    return false;
                }

                if (!m.ContainsGenericParameter)
                {
                    return false;
                }

                var genericType = m.GenericParameters.FirstOrDefault();
                if (genericType == null)
                {
                    return false;
                }

                // get method signature
                var methodSignature = m.ToString();
                var setPropertySianatureA = string.Format("System.Boolean {0}::SetProperty({1}&,{1},System.String)", m.DeclaringType.FullName, genericType);
                var setPropertySianatureB = string.Format("System.Boolean {0}::SetProperty({1},{1},System.Action`1<{1}>,System.String)", m.DeclaringType.FullName, genericType);

                // verify signature
                if (methodSignature == setPropertySianatureA)
                {
                    return true;
                }
                else if (methodSignature == setPropertySianatureB)
                {
                    return true;
                }

                return false;
            });

            return result;
        }

        private bool IsBindableClass(TypeDefinition typeDefinition)
        {
            if (!typeDefinition.IsClass)
            {
                return false;
            }

            if (!typeDefinition.HasInterfaces)
            {
                return false;
            }

            // check implements interface
            if (!implementsInterface(typeDefinition))
            {
                return false;
            }

            // check "NotifyPropertyChanged" method
            var methods = GetNotifyPropertyChangedMethods(typeDefinition.Methods);
            var notifyMethod = methods.FirstOrDefault();
            if (notifyMethod == null)
            {
                return false;
            }

            // check method "SetProperty"
            var setPropertyMethods = GetSetPropertyMethods(typeDefinition.Methods);

            // must have both methods
            if (setPropertyMethods.Count() == 2)
            {
                return true;
            }

            return false;
        }

        private bool ImplementsINotifyPropertyChangedV1(TypeDefinition typeDefinition)
        {
            IEnumerable interfacesValue = (IEnumerable)interfacesProperty.GetValue(typeDefinition, null);
            var interfaces = interfacesValue.Cast<object>();

            bool result = interfaces.Any(x =>
            {
                var value = (TypeReference)x;
                return value.FullName == InterfaceFullName;
            });

            return result;
        }

        private bool ImplementsINotifyPropertyChangedV2(TypeDefinition typeDefinition)
        {
            IEnumerable interfacesValue = (IEnumerable)interfacesProperty.GetValue(typeDefinition, null);
            var interfaces = interfacesValue.Cast<object>();

            bool result = interfaces.Any(x =>
            {
                var value = (TypeReference)interfaceTypeProperty.GetValue(x, null);
                return value.FullName == InterfaceFullName;
            });

            return result;
        }

        private bool LoadModules(string directory)
        {
            // reset
            frameworkModule = null;
            typeList = new List<TypeDefinition>();

            // scan all assemblies
            var files = Directory.GetFiles(directory);

            // first find framework assembly
            foreach (var file in files)
            {
                if (!file.EndsWith(".dll"))
                {
                    // skip non dll
                    continue;
                }

                var m = ModuleDefinition.ReadModule(file);

                // get interface type
                var interfaceType = m.Types.Where(x =>
                {
                    if (InterfaceFullName == x.FullName)
                    {
                        return true;
                    }

                    return false;
                }).FirstOrDefault();

                if (interfaceType != null)
                {
                    // find framework
                    frameworkModule = m;
                    break;
                }
            }

            if (frameworkModule == null)
            {
#if UNITY
                Debug.LogError("INotifyPropertyChanged type is not found.");
#else
                Console.WriteLine("INotifyPropertyChanged type is not found.");
#endif
                // framework not found
                return false;
            }

            // create module list
            var moduleList = new List<ModuleDefinition>();

            // add itself
            moduleList.Add(frameworkModule);

            // load all dependencies
            foreach (var file in files)
            {
                if (!file.EndsWith(".dll"))
                {
                    // skip non dll
                    continue;
                }

                var m = ModuleDefinition.ReadModule(file);
                if (m.Name == frameworkModule.Name)
                {
                    // skip framework
                    continue;
                }

                // check if assembly references contains framework
                bool valid = m.AssemblyReferences.Any(x => x.FullName == frameworkModule.Assembly.FullName);

                if (valid)
                {
                    // add it
                    moduleList.Add(m);
                }
            }

            // load all types
            foreach (var item in moduleList)
            {
                typeList.AddRange(item.Types);
            }

            return true;
        }
    }
}
