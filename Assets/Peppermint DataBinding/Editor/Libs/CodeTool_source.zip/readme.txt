﻿The CodeTool is an editor tool, which is used to verify property names in game assembly. If you need to modify the tool to meet your own requirements, please follow the instructions below.

First, you need to copy the following files from "Unity\Editor\Data\Managed" to the lib directory.
UnityEngine.dll
UnityEditor.dll
Unity.Cecil.dll (for Unity 2017.2 and later) / Mono.Cecil.dll

To build the project, just open the CodeTool.csproj in Visual Studio, and choose the proper configuration. There are two release configuartions:
"Release_UnityCecil" is for Unity 2017.2 and later.
"Release_MonoCecil" is for Unity 5.2 - 2017.1.

Finally, copy the generated CodeTool.dll to "Peppermint DataBinding\Editor\Libs" and replace the old file.